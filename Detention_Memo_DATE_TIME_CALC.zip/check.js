
const $=x=>document.getElementById(x), deps=['TFC','LOCO','ENGG','C&W','Comm.','MISC'];
const pad=n=>String(n).padStart(2,'0');
let d=new Date(); $('date').value=d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());
function md(a,b){if(!a||!b)return null;let x=a.split(':').map(Number),y=b.split(':').map(Number),z=y[0]*60+y[1]-x[0]*60-x[1];if(z<-720)z+=1440;if(z>720)z-=1440;return z}
function dispMin(n){n=Math.abs(Number(n)||0);if(n<60)return n+' min.';let h=Math.floor(n/60),m=n%60;return h+' hour'+(h===1?'':'s')+' '+m+' min.'}
function status(st,t,w,a){let z=md(w,a);if(z===null)return '';return st+' '+t+' '+a+' '+(z===0?'RT':dispMin(z)+' '+(z>0?'Late':'Before'))}
function ren(){document.querySelectorAll('#et tbody tr').forEach((r,i)=>r.children[0].textContent=i+1)}
function add(before=null){
 const r=document.createElement('tr');
 r.innerHTML='<td></td><td><input class="s" autocomplete="off"></td><td><input class="v" type="number" min="0" autocomplete="off"></td><td><input class="r" autocomplete="off"></td><td><select class="q"><option value=""></option>'+deps.map(x=>'<option>'+x+'</option>').join('')+'</select></td><td class="row-actions"><button type="button" class="ins">↑</button> <button type="button" class="x">×</button></td>';
 const tb=$('et').querySelector('tbody'); if(before)tb.insertBefore(r,before);else tb.appendChild(r);
 r.querySelectorAll('input,select').forEach(e=>e.addEventListener('input',()=>{calc();saveState();}));
 r.querySelector('.x').addEventListener('click',()=>{r.remove();ren();calc();saveState()});
 r.querySelector('.ins').addEventListener('click',()=>{add(r);saveState();});
 ren();calc();
}
$('add').addEventListener('click',()=>{add();saveState();});
for(let i=0;i<3;i++)add();
function calc(){
 let L={TFC:0,LOCO:0,ENGG:0,'C&W':0,'Comm.':0,MISC:0},sum=0;
 document.querySelectorAll('#et tbody tr').forEach(r=>{let n=Number(r.querySelector('.v').value)||0,q=r.querySelector('.q').value;if(q)L[q]+=n});
 sum=Object.values(L).reduce((a,b)=>a+b,0);
 let dep=md($('wd').value,$('ad').value)||0,lsL=Math.max(dep,0),lsG=Math.max(-dep,0),loss=sum+lsL;
 let arr=md($('wa').value,$('aa').value),gain=arr===null?0:loss-arr;
 let enggG=Number($('givenEngg').value||0),tfcG=gain-lsG-enggG;
 [['ltfc',L.TFC],['lloco',L.LOCO],['lengg',L.ENGG],['lcw',L['C&W']],['lcom',L['Comm.']],['lmisc',L.MISC],['lls',lsL],['ltot',loss],['gtfc',tfcG],['gengg',enggG],['gls',lsG],['gtot',gain]].forEach(x=>$(x[0]).textContent=x[1]);
 $('pun').textContent='Punctuality = '+(arr===null?'—':arr===0?'RT':dispMin(arr)+' '+(arr>0?'Late':'Before'));
 $('pun').classList.remove('late','before'); if(arr>0)$('pun').classList.add('late'); else if(arr<0)$('pun').classList.add('before');
 $('times').innerHTML=status($('ds').value,'DEP',$('wd').value,$('ad').value)+'<br>'+status($('as').value,'AR',$('wa').value,$('aa').value);
}
document.querySelectorAll('input,select').forEach(e=>e.addEventListener('input',()=>{calc();saveState();}));
const STORE_KEY='arrivalMemoOfflineStateV1';
function collectState(){
  return {
    date:$('date').value,train:$('train').value,loco:$('loco').value,lp:$('lp').value,tm:$('tm').value,
    load:$('load').value,slr:$('slr').value,osr:$('osr').value,ds:$('ds').value,wd:$('wd').value,ad:$('ad').value,
    as:$('as').value,wa:$('wa').value,aa:$('aa').value,
    wdLocked:$('wd').readOnly,waLocked:$('wa').readOnly,
    given:$('given').value,givenEngg:$('givenEngg').value,gainsLocked:$('given').readOnly,
    rows:[...document.querySelectorAll('#et tbody tr')].map(r=>({
      s:r.querySelector('.s').value,v:r.querySelector('.v').value,r:r.querySelector('.r').value,q:r.querySelector('.q').value
    }))
  };
}
function saveState(){
  try{localStorage.setItem(STORE_KEY,JSON.stringify(collectState()));}catch(e){}
}
function applyLockedState(){
  if($('wd').readOnly){$('wd').classList.add('locked');}
  if($('wa').readOnly){$('wa').classList.add('locked');}
  if($('given').readOnly){$('given').classList.add('locked');}
  if($('givenEngg').readOnly){$('givenEngg').classList.add('locked');}
}
function restoreState(){
  try{
    const raw=localStorage.getItem(STORE_KEY); if(!raw)return false;
    const st=JSON.parse(raw); if(!st||typeof st!=='object')return false;
    ['date','train','loco','lp','tm','load','slr','osr','ds','wd','ad','as','wa','aa','given','givenEngg'].forEach(id=>{
      if(st[id]!==undefined)$(id).value=st[id];
    });
    if(st.wdLocked)$('wd').readOnly=true;
    if(st.waLocked)$('wa').readOnly=true;
    if(st.wdLocked && st.waLocked){$('lock').textContent='WTT Times Locked ✓';$('lock').classList.add('sky');}
    if(st.gainsLocked){$('given').readOnly=true;$('givenEngg').readOnly=true;$('lockGains').textContent='Given Gains Locked ✓';$('lockGains').classList.add('sky');}
    const tb=$('et').querySelector('tbody'); tb.innerHTML='';
    (Array.isArray(st.rows)?st.rows:[]).forEach(row=>{
      add(); const r=tb.lastElementChild;
      r.querySelector('.s').value=row.s||'';r.querySelector('.v').value=row.v||'';r.querySelector('.r').value=row.r||'';r.querySelector('.q').value=row.q||'';
    });
    if(!tb.children.length)for(let i=0;i<3;i++)add();
    ren();applyLockedState();calc();return true;
  }catch(e){return false;}
}
$('lock').addEventListener('click',()=>{if(!$('wd').value||!$('wa').value){alert('Enter WTT DEP and WTT AR');return}$('wd').readOnly=true;$('wa').readOnly=true;$('wd').classList.add('locked');$('wa').classList.add('locked');$('lock').textContent='WTT Times Locked ✓';$('lock').classList.add('sky');$('times').classList.add('ok');saveState();});
$('lockGains').addEventListener('click',()=>{$('given').readOnly=true;$('givenEngg').readOnly=true;$('given').classList.add('locked');$('givenEngg').classList.add('locked');$('lockGains').textContent='Given Gains Locked ✓';$('lockGains').classList.add('sky');calc();saveState()});
function validate(){
 const required=['date','train','loco','lp','tm','load','osr','ds','wd','ad','as','wa','aa'];
 let incomplete=required.some(id=>String($(id).value||'').trim()==='');
 const rows=[...document.querySelectorAll('#et tbody tr')]; if(!rows.length)incomplete=true;
 rows.forEach(r=>['.s','.v','.r','.q'].forEach(sel=>{if(String(r.querySelector(sel).value||'').trim()==='')incomplete=true}));
 if(incomplete){$('err').style.display='block';$('err').textContent='Fill Complete Details';return false}
 if(Number($('gtfc').textContent)<Number($('given').value||0)){ $('err').style.display='block';$('err').textContent='TFC Gain is Less then Given WTT TFC Gain Please Check Detation Entries';return false }
 $('err').style.display='none';return true
}
function zx(n){return Number(n)===0?'X':n}
function fmtDate(v){if(!v)return '';let [y,m,day]=v.split('-');return day+'/'+m+'/'+y}
function drawCell(doc,x,y,w,h,text,opt={}){
 const fill=opt.fill||false; const bold=!!opt.bold; const align=opt.align||'left'; const fs=opt.fs||8.5;
 if(fill)doc.setFillColor(255,255,0); else doc.setFillColor(255,255,255);
 doc.setDrawColor(185,185,185); doc.rect(x,y,w,h,fill?'FD':'S'); doc.setFont('helvetica',bold?'bold':'normal'); doc.setFontSize(fs);
 let tx=x+2;if(align==='center')tx=x+w/2;if(align==='right')tx=x+w-2;
 doc.text(String(text??''),tx,y+h/2+fs*0.34,{align});
}
function drawWrapCell(doc,x,y,w,h,text,opt={}){
 const fill=opt.fill||false,bold=!!opt.bold,fs=opt.fs||8.2;
 if(fill)doc.setFillColor(255,255,0);else doc.setFillColor(255,255,255);
 doc.setDrawColor(185,185,185);doc.rect(x,y,w,h,fill?'FD':'S');doc.setFont('helvetica',bold?'bold':'normal');doc.setFontSize(fs);
 let lines=doc.splitTextToSize(String(text??''),w-4);let lineH=fs*0.42;let total=lines.length*lineH;let yy=y+(h-total)/2+fs*0.35;doc.text(lines.slice(0,3),x+w/2,yy,{align:'center'});
}
async function make(){
 if(!validate())return null;
 const J=window.jspdf.jsPDF,doc=new J({unit:'mm',format:'a4'});
 const pageW=210, margin=12, W=pageW-margin*2;
 let y=12;
 const lineH=6.5;
 const ensure=(need)=>{if(y+need>282){doc.addPage();y=12;}};
 const border=()=>{doc.setDrawColor(0,0,0);doc.setLineWidth(0.25)};
 const cell=(x,yy,w,h,text,opt={})=>{
   border();doc.setFillColor(255,255,255);doc.rect(x,yy,w,h,'S');
   doc.setFont('helvetica','bold');doc.setFontSize(opt.fs||8.5);doc.setTextColor(0,0,0);
   const align=opt.align||'center';
   const lines=doc.splitTextToSize(String(text??''),Math.max(3,w-4));
   const lh=(opt.fs||8.5)*0.42; const maxLines=Math.max(1,Math.floor((h-2)/lh));
   const use=lines.slice(0,maxLines); const total=use.length*lh;
   let yyText=yy+(h-total)/2+(opt.fs||8.5)*0.32;
   doc.text(use, x+w/2, yyText,{align:'center'});
 };
 const header=(text,h=8,fs=11)=>{ensure(h);cell(margin,y,W,h,text,{fs});y+=h};
 const twoCol=(rows)=>{
   const c=[margin,margin+28,margin+105,margin+133,margin+W];
   rows.forEach(r=>{
     ensure(lineH); cell(c[0],y,c[1]-c[0],lineH,r[0],{fs:8}); cell(c[1],y,c[2]-c[1],lineH,r[1],{fs:8});
     cell(c[2],y,c[3]-c[2],lineH,r[2],{fs:8}); cell(c[3],y,c[4]-c[3],lineH,r[3],{fs:8}); y+=lineH;
   });
 };
 header('ARRIVAL MEMO',9,12);
 twoCol([
  ['DATE',fmtDate($('date').value),'TRAIN NO',$('train').value],
  ['LOCO NO',$('loco').value,'LP',$('lp').value],
  ['TM',$('tm').value,'LOAD',$('load').value+'='+Number($('load').value)*2],
  ['SLR',$('slr').value,'OSR',$('osr').value]
 ]);
 ensure(lineH*3+2); cell(margin,y,W,lineH,'TIMING',{fs:8.5}); y+=lineH;
 const tc=[margin,margin+28,margin+78,margin+112,margin+W];
 ['TYPE','STATION','WTT','ACTUAL','RESULT'].forEach((t,i)=>cell(tc[i],y,tc[i+1]-tc[i],lineH,t,{fs:8}));y+=lineH;
 [
  ['DEP',$('ds').value,$('wd').value,$('ad').value,status('',$('ds').value,$('wd').value,$('ad').value).replace($('ds').value+' ','')],
  ['AR',$('as').value,$('wa').value,$('aa').value,status('',$('as').value,$('wa').value,$('aa').value).replace($('as').value+' ','')]
 ].forEach(r=>{ensure(lineH);r.forEach((v,i)=>cell(tc[i],y,tc[i+1]-tc[i],lineH,v,{fs:8}));y+=lineH});
 y+=3;
 ensure(12); cell(margin,y,W,lineH,'DETENTION ENTRIES',{fs:8.5});y+=lineH;
 const dc=[margin,margin+18,margin+70,margin+90,margin+W];
 ['S.NO.','SECTION / STATION','T/L','REASON'].forEach((t,i)=>{if(i<4)cell(dc[i],y,dc[i+1]-dc[i],lineH,t,{fs:8})});y+=lineH;
 const rows=[...document.querySelectorAll('#et tbody tr')];
 rows.forEach(r=>{
   const reason=r.querySelector('.r').value;
   const sec=r.querySelector('.s').value;
   const v=r.querySelector('.v').value;
   const reasonLines=doc.splitTextToSize(reason, W-(dc[3]-margin)-4);
   const rh=Math.max(lineH,Math.min(18,reasonLines.length*3.8+2));
   ensure(rh);
   cell(dc[0],y,dc[1]-dc[0],rh,r.children[0].textContent,{fs:8});
   cell(dc[1],y,dc[2]-dc[1],rh,sec,{fs:8});
   cell(dc[2],y,dc[3]-dc[2],rh,v,{fs:8});
   cell(dc[3],y,dc[4]-dc[3],rh,reason,{fs:8});
   y+=rh;
 });
 ensure(lineH);cell(margin,y,dc[3]-margin,lineH,'TOTAL',{fs:8.5});cell(dc[3],y,dc[4]-dc[3],lineH,$('ltot').textContent,{fs:8.5});y+=lineH+8;
 ensure(lineH*3+2);cell(margin,y,W,lineH,'LOSS / GAIN',{fs:8.5});y+=lineH;
 const sw=W/9;
 let xx=margin;
 ['', 'TFC','LOCO','ENGG','C&W','Comm.','MISC','L/S','TOTAL'].forEach(t=>{cell(xx,y,sw,lineH,t,{fs:7.8});xx+=sw});y+=lineH;
 const lossVals=[zx($('ltfc').textContent),zx($('lloco').textContent),zx($('lengg').textContent),zx($('lcw').textContent),zx($('lcom').textContent),zx($('lmisc').textContent),zx($('lls').textContent),$('ltot').textContent];
 xx=margin;['LOSS',...lossVals].forEach(v=>{cell(xx,y,sw,lineH,v,{fs:7.8});xx+=sw});y+=lineH;
 const gainVals=[zx($('gtfc').textContent),'X',zx($('gengg').textContent),'X','X','X',zx($('gls').textContent),$('gtot').textContent];
 xx=margin;['GAIN',...gainVals].forEach(v=>{cell(xx,y,sw,lineH,v,{fs:7.8});xx+=sw});y+=lineH+9;
 ensure(8);doc.setFont('helvetica','bold');doc.setFontSize(9);doc.setTextColor(0,0,0);doc.text($('pun').textContent,pageW/2,y,{align:'center'});
 const name=$('train').value+'.pdf';return {blob:doc.output('blob'),name,doc};
}

/* Offline-safe PDF fallback: if jsPDF CDN is unavailable, build a simple real PDF locally. */
function pdfEsc(v){return String(v??'').replace(/[^\x20-\x7E]/g,'?').replace(/\\/g,'\\\\').replace(/\(/g,'\\(').replace(/\)/g,'\\)');}
function wrapPdf(text,maxChars){
  const words=String(text??'').split(/\s+/), out=[]; let line='';
  words.forEach(w=>{if(!line)line=w;else if((line+' '+w).length<=maxChars)line+=' '+w;else{out.push(line);line=w;}}); if(line||!out.length)out.push(line); return out;
}
function makeFallbackPDF(){
  if(!validate()) return null;
  const W=595.28,H=841.89,margin=36,usable=W-margin*2;
  const pages=[[]];let page=0,y=H-36;
  const newPage=()=>{pages.push([]);page++;y=H-36;};
  const ensure=h=>{if(y-h<34)newPage();};
  const esc=v=>String(v??'').replace(/[^\x20-\x7E]/g,'?').replace(/\\/g,'\\\\').replace(/\(/g,'\\(').replace(/\)/g,'\\)');
  const wrap=(text,max)=>{const words=String(text??'').split(/\s+/),out=[];let line='';words.forEach(w=>{if(!line)line=w;else if((line+' '+w).length<=max)line+=' '+w;else{out.push(line);line=w;}});if(line||!out.length)out.push(line);return out;};
  const rect=(x,yy,w,h,fill)=>{if(fill){pages[page].push(`${fill} rg ${x.toFixed(2)} ${yy.toFixed(2)} ${w.toFixed(2)} ${h.toFixed(2)} re f`);}pages[page].push(`0.55 0.68 0.77 RG 0.55 w ${x.toFixed(2)} ${yy.toFixed(2)} ${w.toFixed(2)} ${h.toFixed(2)} re S`);};
  const text=(x,yy,str,size=8.5,align='center')=>{const t=esc(str),approx=t.length*size*.47;let xx=x;if(align==='center')xx=x-approx/2;else if(align==='right')xx=x-approx;pages[page].push(`BT /F2 ${size} Tf 0.09 0.20 0.27 rg 1 0 0 1 ${xx.toFixed(2)} ${yy.toFixed(2)} Tm (${t}) Tj ET`);};
  const cell=(x,yy,w,h,val,size=8.5,align='center',fill='')=>{rect(x,yy,w,h,fill);const lines=wrap(val,Math.max(8,Math.floor(w/(size*.55)))).slice(0,3),lh=size+1.4,total=lines.length*lh;let sy=yy+(h+total)/2-lh+2;lines.forEach((ln,i)=>text(align==='left'?x+4:align==='right'?x+w-4:x+w/2,sy-i*lh,ln,size,align));};
  const row=(label,value,h=24)=>{ensure(h);cell(margin,y,usable,h,label+' - '+value,8.8,'left','0.97 0.99 1');y-=h;};
  const timingLine=(station,kind,wtt,actual)=>{const z=md(wtt,actual);return `${station} ${kind} - ${actual} ${z===null?'':z===0?'RT':dispMin(z)+' '+(z>0?'Late':'Before')}`;};
  ensure(32);cell(margin,y,usable,32,'ARRIVAL MEMO',15,'center','0.90 0.95 0.98');y-=32;
  row('DATE',fmtDate($('date').value));row('TRAIN NO',$('train').value);row('LOCO NO',$('loco').value);row('LP',$('lp').value);row('TM',$('tm').value);row('LOAD',$('load').value+'='+Number($('load').value)*2);row('SLR',$('slr').value);row('OSR',$('osr').value);
  y-=4;ensure(25);cell(margin,y,usable,22,timingLine($('ds').value,'DEP',$('wd').value,$('ad').value),9,'left','0.96 0.98 1');y-=25;cell(margin,y,usable,22,timingLine($('as').value,'AR',$('wa').value,$('aa').value),9,'left','0.96 0.98 1');y-=28;
  const rows=[...document.querySelectorAll('#et tbody tr')];const cols=[margin,margin+34,margin+208,margin+250,margin+usable];
  const detentionCell=(x,yy,w,h,val,size=8.2,align='center',fill='')=>{
    if(fill) pages[page].push(`${fill} rg ${x.toFixed(2)} ${yy.toFixed(2)} ${w.toFixed(2)} ${h.toFixed(2)} re f`);
    const lines=wrap(val,Math.max(8,Math.floor(w/(size*.55)))).slice(0,3),lh=size+1.4,total=lines.length*lh;
    let sy=yy+(h+total)/2-lh+2;
    lines.forEach((ln,i)=>text(align==='left'?x+4:align==='right'?x+w-4:x+w/2,sy-i*lh,ln,size,align));
  };
  ensure(26);
  const headY=y, headH=25;
  ['S.NO.','SECTION / STATION','T/L','REASON'].forEach((v,i)=>detentionCell(cols[i],headY,cols[i+1]-cols[i],headH,v,8,'center','0.90 0.95 0.98'));
  y-=headH;
  const detentionRows=[];
  rows.forEach(r=>{
    const vals=[r.children[0].textContent,r.querySelector('.s').value,r.querySelector('.v').value,r.querySelector('.r').value];
    const lines=wrap(vals[3],Math.max(18,Math.floor((cols[3]-cols[2]-6)/5.1)));
    const h=Math.max(24,Math.min(44,lines.length*10+6));
    ensure(h);
    detentionRows.push({y,h,vals});
    for(let i=0;i<4;i++)detentionCell(cols[i],y,cols[i+1]-cols[i],h,vals[i],8.2);
    y-=h;
  });
  // Draw the detention grid ONCE. Do not draw a rectangle for every cell:
  // overlapping cell borders can occasionally produce a stray/jagged line
  // on Android PDF renderers. One shared grid is deterministic.
  const gridTop=headY, gridBottom=y;
  for(let i=0;i<cols.length;i++) pages[page].push(`0.55 0.68 0.77 RG 0.55 w ${cols[i].toFixed(2)} ${gridBottom.toFixed(2)} m ${cols[i].toFixed(2)} ${gridTop.toFixed(2)} l S`);
  pages[page].push(`0.55 0.68 0.77 RG 0.55 w ${cols[0].toFixed(2)} ${gridTop.toFixed(2)} m ${cols[4].toFixed(2)} ${gridTop.toFixed(2)} l S`);
  pages[page].push(`0.55 0.68 0.77 RG 0.55 w ${cols[0].toFixed(2)} ${gridBottom.toFixed(2)} m ${cols[4].toFixed(2)} ${gridBottom.toFixed(2)} l S`);
  detentionRows.forEach(row=>{const yy=row.y;pages[page].push(`0.55 0.68 0.77 RG 0.55 w ${cols[0].toFixed(2)} ${yy.toFixed(2)} m ${cols[4].toFixed(2)} ${yy.toFixed(2)} l S`);});
  ensure(26);cell(cols[0],y,cols[1]-cols[0],25,'',8);cell(cols[1],y,cols[2]-cols[1],25,'TOTAL',8.5,'center','0.94 0.97 0.99');cell(cols[2],y,cols[3]-cols[2],25,$('ltot').textContent,8.5,'center','0.94 0.97 0.99');cell(cols[3],y,cols[4]-cols[3],25,'',8);y-=33;
  const sw=usable/9;ensure(76);let xx=margin;['','TFC','LOCO','ENGG','C&W','Comm.','MISC','L/S','TOTAL'].forEach(v=>{cell(xx,y,sw,24,v,7.4,'center','0.93 0.90 0.97');xx+=sw});y-=24;xx=margin;['LOSS',zx($('ltfc').textContent),zx($('lloco').textContent),zx($('lengg').textContent),zx($('lcw').textContent),zx($('lcom').textContent),zx($('lmisc').textContent),zx($('lls').textContent),$('ltot').textContent].forEach(v=>{cell(xx,y,sw,24,v,7.4);xx+=sw});y-=24;xx=margin;['GAIN',zx($('gtfc').textContent),'X',zx($('gengg').textContent),'X','X','X',zx($('gls').textContent),$('gtot').textContent].forEach(v=>{cell(xx,y,sw,24,v,7.4);xx+=sw});y-=31;
  ensure(22);const ptxt=$('pun').textContent||'';const pfill=/Late/i.test(ptxt)?'1 0.95 0.94':'0.91 0.97 0.95';cell(margin,y,usable,22,$('pun').textContent,10,'center',pfill);
  const contents=pages.map(p=>p.join('\n'));let n=3;const pageIds=[],contIds=[];for(let i=0;i<pages.length;i++){pageIds.push(n++);contIds.push(n++);}const fontId=n++;const objs=[];objs[1]='<< /Type /Catalog /Pages 2 0 R >>';objs[2]=`<< /Type /Pages /Kids [${pageIds.map(id=>id+' 0 R').join(' ')}] /Count ${pageIds.length} >>`;pageIds.forEach((id,i)=>{objs[id]=`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${W} ${H}] /Resources << /Font << /F2 ${fontId} 0 R >> >> /Contents ${contIds[i]} 0 R >>`;objs[contIds[i]]=`<< /Length ${contents[i].length} >>\nstream\n${contents[i]}\nendstream`;});objs[fontId]='<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>';let out='%PDF-1.4\n%âãÏÓ\n',offs=[0];for(let i=1;i<objs.length;i++){offs[i]=out.length;out+=`${i} 0 obj\n${objs[i]}\nendobj\n`;}const xref=out.length;out+=`xref\n0 ${objs.length}\n0000000000 65535 f \n`;for(let i=1;i<objs.length;i++)out+=String(offs[i]).padStart(10,'0')+' 00000 n \n';out+=`trailer\n<< /Size ${objs.length} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;return {blob:new Blob([out],{type:'application/pdf'}),name:$('train').value+'.pdf'};
}
async function makePackage(){
  return makeFallbackPDF();
}
function printPdfBlob(blob){
  try{
    const u=URL.createObjectURL(blob);
    const w=window.open(u,'_blank');
    if(w){
      setTimeout(()=>{try{w.focus();w.print();}catch(e){}},700);
      setTimeout(()=>URL.revokeObjectURL(u),60000);
      return true;
    }
  }catch(e){}
  return false;
}
async function blobBase64(blob){
  const buf=await blob.arrayBuffer();
  const bytes=new Uint8Array(buf);
  let bin='';
  // Build the binary string without a large spread call. This is more reliable
  // on Android WebView and avoids stack/argument-limit failures on larger PDFs.
  for(let i=0;i<bytes.length;i++){ bin += String.fromCharCode(bytes[i]); }
  return btoa(bin);
}
function downloadBlob(blob,name){const u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),1500);}
$('pdf').addEventListener('click',async()=>{
  try{
    const p=await makePackage();
    if(!p)return;
    if(window.Android && typeof Android.savePdf==='function'){
      const b64=await blobBase64(p.blob);
      Android.savePdf(b64,p.name);
      return;
    }
    downloadBlob(p.blob,p.name);
  }catch(e){
    console.error(e);
    alert('PDF Save failed. Please try again.');
  }
});
$('share').addEventListener('click',async()=>{
  try{
    const p=await makePackage();
    if(!p)return;
    if(window.Android && typeof Android.sharePdf==='function'){
      const b64=await blobBase64(p.blob);
      Android.sharePdf(b64,p.name);
      return;
    }
    const f=new File([p.blob],p.name,{type:'application/pdf'});
    if(navigator.share && (!navigator.canShare || navigator.canShare({files:[f]}))){
      await navigator.share({files:[f],title:p.name,text:'Arrival Memo PDF'});
      return;
    }
    downloadBlob(p.blob,p.name);
    alert('PDF saved. अब WhatsApp में PDF चुनकर भेजें।');
  }catch(e){
    if(e && e.name==='AbortError')return;
    console.error(e);
    alert('Share PDF failed. Please try again.');
  }
});


// Restore the last working memo automatically whenever the offline app opens.
restoreState();
window.addEventListener('beforeunload',()=>{if(!window.__clearingMemo) saveState();});

// Clear/New Memo: remove saved data and reset the form without changing the baseline calculations.
$('clear').addEventListener('click',()=>{
  try{ if(window.Android && Android.clearNewMemo){ Android.clearNewMemo(); return; } }catch(e){}
  if(!confirm('Are you sure you want to start a New Memo?\nCurrent unsaved data will be cleared.')) return;
  window.__clearingMemo=true;
  try{localStorage.removeItem(STORE_KEY);}catch(e){}
  location.reload();
});

// About button: use the native Android dialog when available so the i button
// remains reliable inside Android WebView; fall back to the offline HTML modal.
function openAbout(){
  try{
    if(window.Android && Android.showAbout){ Android.showAbout(); return; }
  }catch(e){}
  $('aboutModal').style.display='flex';
}
$('about').addEventListener('click',openAbout);
$('about').addEventListener('touchend',function(e){e.preventDefault();openAbout();},{passive:false});
$('closeAbout').addEventListener('click',()=>{$('aboutModal').style.display='none';});
$('aboutModal').addEventListener('click',e=>{if(e.target.id==='aboutModal')$('aboutModal').style.display='none';});


