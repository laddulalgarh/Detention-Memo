DETENTION MEMO - Android Project v2

यह project Detention Memo के offline Android app के लिए तैयार है।
मुख्य source: app/src/main/assets/index.html
App name: Detention Memo
Version: 1.0
Created by: Chander Mohan Meena SPTM Guna

Android Studio में:
1. इस पूरे 'DetentionMemoAndroid' folder को Android Studio में Open करें।
2. पहली बार Android Studio को Gradle/Android SDK components download करने पड़ सकते हैं।
3. Project sync पूरा होने दें।
4. ऊपर Build menu में जाकर 'Build APK(s)' दबाएँ।
5. APK आम तौर पर: app/build/outputs/apk/debug/app-debug.apk

महत्वपूर्ण:
- App source पूरी तरह offline है; HTML में कोई online CDN dependency नहीं रखी जानी चाहिए।
- Android app का काम local WebView में चलता है।
- Portrait orientation रखी गई है ताकि phone layout न बिगड़े।
- Backup/background service नहीं जोड़ी गई है।
- v10 approved calculation baseline को बदला नहीं जाना चाहिए; future changes केवल user की स्पष्ट अनुमति से करें।
